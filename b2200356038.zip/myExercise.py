import sys
student_info=dict()
inputs=open(sys.argv[1]).read().splitlines()
input_txt=sys.argv[2].split(",")
for k in inputs:
    t1=k.split(":")
    t2=t1[1].split(",")
    student_info[t1[0]]=t2
print(student_info)
output_txt=""
for k in input_txt:
    try:
        student_info[k]
        output_txt+="Name:"+k+", University:"+student_info[k][0]+" "+student_info[k][1]
    except:
        output_txt+=" No record of ‘{}’ was found!".format(k)
print(output_txt)